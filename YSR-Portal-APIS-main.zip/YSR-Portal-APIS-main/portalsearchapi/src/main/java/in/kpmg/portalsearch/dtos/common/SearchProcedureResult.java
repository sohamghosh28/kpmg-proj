package in.kpmg.portalsearch.dtos.common;

//import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class SearchProcedureResult {
	@Id
	//private BigInteger appid;
	private String specialityCode;
	private String specialityName;
	private String dissubId;
	private String dissubName;
	private String surgeryId;
	private String surgdispCode;
	private String procedureName;
	private String procedureType;
	private int packageAmount;
	private int hospstayAmt;
	private int commoncatAmt;
	private int icdAmt;
	private int aasaraAmt;
	public int getAasaraAmt() {
		return aasaraAmt;
	}
	public void setAasaraAmt(int aasaraAmt) {
		this.aasaraAmt = aasaraAmt;
	}
	private String hospstayamtGovt;
	private int duration;
	private String isPerdm;
	private String preInvestigations;
	private String postInvestigations;
	private String medInvestigations;
	//private Double count;
	
	public String getSpecialityCode() {
		return specialityCode;
	}
	public void setSpecialityCode(String specialityCode) {
		this.specialityCode = specialityCode;
	}
	public String getSpecialityName() {
		return specialityName;
	}
	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}
	public String getDissubId() {
		return dissubId;
	}
	public void setDissubId(String dissubId) {
		this.dissubId = dissubId;
	}
	public String getDissubName() {
		return dissubName;
	}
	public void setDissubName(String dissubName) {
		this.dissubName = dissubName;
	}
	public String getSurgeryId() {
		return surgeryId;
	}
	public void setSurgeryId(String surgeryId) {
		this.surgeryId = surgeryId;
	}
	public String getSurgdispCode() {
		return surgdispCode;
	}
	public void setSurgdispCode(String surgdispCode) {
		this.surgdispCode = surgdispCode;
	}
	public String getProcedureName() {
		return procedureName;
	}
	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}
	public String getProcedureType() {
		return procedureType;
	}
	public void setProcedureType(String procedureType) {
		this.procedureType = procedureType;
	}
	public int getPackageAmount() {
		return packageAmount;
	}
	public void setPackageAmount(int packageAmount) {
		this.packageAmount = packageAmount;
	}
	public int getHospstayAmt() {
		return hospstayAmt;
	}
	public void setHospstayAmt(int hospstayAmt) {
		this.hospstayAmt = hospstayAmt;
	}
	public int getCommoncatAmt() {
		return commoncatAmt;
	}
	public void setCommoncatAmt(int commoncatAmt) {
		this.commoncatAmt = commoncatAmt;
	}
	public int getIcdAmt() {
		return icdAmt;
	}
	public void setIcdAmt(int icdAmt) {
		this.icdAmt = icdAmt;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getIsPerdm() {
		return isPerdm;
	}
	public void setIsPerdm(String isPerdm) {
		this.isPerdm = isPerdm;
	}
	public String getPreInvestigations() {
		return preInvestigations;
	}
	public void setPreInvestigations(String preInvestigations) {
		this.preInvestigations = preInvestigations;
	}
	public String getPostInvestigations() {
		return postInvestigations;
	}
	public void setPostInvestigations(String postInvestigations) {
		this.postInvestigations = postInvestigations;
	}
	public String getMedInvestigations() {
		return medInvestigations;
	}
	public void setMedInvestigations(String medInvestigations) {
		this.medInvestigations = medInvestigations;
	}
	public SearchProcedureResult() {
	}
	/*public Double getCount() {
		return count;
	}
	public void setCount(Double count) {
		this.count = count;
	}*/
	public String getHospstayamtGovt() {
		return hospstayamtGovt;
	}
	public void setHospstayamtGovt(String hospstayamtGovt) {
		this.hospstayamtGovt = hospstayamtGovt;
	}

}