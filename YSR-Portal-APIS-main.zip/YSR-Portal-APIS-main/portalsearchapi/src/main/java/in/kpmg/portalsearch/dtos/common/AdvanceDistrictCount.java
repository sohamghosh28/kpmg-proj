package in.kpmg.portalsearch.dtos.common;

public class AdvanceDistrictCount {
	private String stateVal;

	public String getStateVal() {
		return stateVal;
	}

	public void setStateVal(String stateVal) {
		this.stateVal = stateVal;
	}
}
