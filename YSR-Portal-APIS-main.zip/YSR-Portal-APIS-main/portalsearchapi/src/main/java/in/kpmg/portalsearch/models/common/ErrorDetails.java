package in.kpmg.portalsearch.models.common;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="T_ERROR_DTLS")
public class ErrorDetails {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ERROR_ID")
    private Integer id;

    @Column(name="TICKET_ID")
    private String ticketId;

    @Column(name="USER_ID")
    private Integer userId;

    @Column(name="ERROR_DETAILS")
    private String errorDetails;

    @Column(name="CREATED_ON")
    @CreationTimestamp
    private Timestamp createdOn;

    public ErrorDetails() {
    }

    public ErrorDetails(Integer id, String ticketId, Integer userId, String errorDetails, Timestamp createdOn) {
        this.id = id;
        this.ticketId = ticketId;
        this.userId = userId;
        this.errorDetails = errorDetails;
        this.createdOn = createdOn;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public Timestamp getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Timestamp createdOn) {
        this.createdOn = createdOn;
    }

    
    
    
}