package in.kpmg.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MitraSearchResult {
	@Id
	private Long mitraCount;
	private int locstateVal;
	public int getLocstateVal() {
		return locstateVal;
	}
	public void setLocstateVal(int locstateVal) {
		this.locstateVal = locstateVal;
	}
	public Long getMitraCount() {
		return mitraCount;
	}
	public void setMitraCount(Long mitraCount) {
		this.mitraCount = mitraCount;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	private String state;
}
