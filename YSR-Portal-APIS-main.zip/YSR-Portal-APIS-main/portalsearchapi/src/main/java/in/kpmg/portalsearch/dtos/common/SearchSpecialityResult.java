package in.kpmg.portalsearch.dtos.common;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class SearchSpecialityResult {
	@Id
	private String hospid;
	private int count;
	private String specialitiesmapped;

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getSpecialitiesmapped() {
		return specialitiesmapped;
	}
	public void setSpecialitiesmapped(String specialitiesmapped) {
		this.specialitiesmapped = specialitiesmapped;
	}
	public String getHospid() {
		return hospid;
	}
	public void setHospid(String hospid) {
		this.hospid = hospid;
	}
	
//	private String specialityName;
//	private String specialityCode;
//	private String procedureName;
//	private String procedureType;
//	private String specialInvestigation;
//	private String TreatmentProtocol;
//	private String AasaraAmt;
//	private String pckgs;
//	private String procedureInvestigation;
//	private String mappedHospitals;
//	private String hospitalid;

//	public SearchSpecialityResult() {
//	}
//
//	public String getSpecialityName() {
//		return specialityName;
//	}
//
//	public void setSpecialityName(String specialityName) {
//		this.specialityName = specialityName;
//	}
//
//	public String getSpecialityCode() {
//		return specialityCode;
//	}
//
//	public void setSpecialityCode(String specialityCode) {
//		this.specialityCode = specialityCode;
//	}
//
//	public String getProcedureName() {
//		return procedureName;
//	}
//
//	public void setProcedureName(String procedureName) {
//		this.procedureName = procedureName;
//	}
//
//	public String getProcedureType() {
//		return procedureType;
//	}
//
//	public void setProcedureType(String procedureType) {
//		this.procedureType = procedureType;
//	}
//
//	public String getSpecialInvestigation() {
//		return specialInvestigation;
//	}
//
//	public void setSpecialInvestigation(String specialInvestigation) {
//		this.specialInvestigation = specialInvestigation;
//	}
//
//	public String getTreatmentProtocol() {
//		return TreatmentProtocol;
//	}
//
//	public void setTreatmentProtocol(String treatmentProtocol) {
//		TreatmentProtocol = treatmentProtocol;
//	}
//
//	public String getAasaraAmt() {
//		return AasaraAmt;
//	}
//
//	public void setAasaraAmt(String aasaraAmt) {
//		AasaraAmt = aasaraAmt;
//	}
//
//	public String getPckgs() {
//		return pckgs;
//	}
//
//	public void setPckgs(String pckgs) {
//		this.pckgs = pckgs;
//	}
//
//	public String getProcedureInvestigation() {
//		return procedureInvestigation;
//	}
//
//	public void setProcedureInvestigation(String procedureInvestigation) {
//		this.procedureInvestigation = procedureInvestigation;
//	}
//
//	public String getMappedHospitals() {
//		return mappedHospitals;
//	}
//
//	public void setMappedHospitals(String mappedHospitals) {
//		this.mappedHospitals = mappedHospitals;
//	}
//
//	public String getHospitalid() {
//		return hospitalid;
//	}
//
//	public void setHospitalid(String hospitalid) {
//		this.hospitalid = hospitalid;
//	}

}