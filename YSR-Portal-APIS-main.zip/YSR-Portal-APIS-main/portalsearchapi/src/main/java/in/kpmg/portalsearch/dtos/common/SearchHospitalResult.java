package in.kpmg.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SearchHospitalResult  {

	@Id
	/*private BigInteger appid;*/
	private String hospitalName;
	private String hospitalType;
	private String hospitalAddress;
	private String districtName;
	//private String mandalName;
	private String specialities;
	private String empanalledDate;
	private String medcoName;
	private String medcoContactNo;
	private String mitraName;
	private String mitraContactNo;

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalType() {
		return hospitalType;
	}

	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;
	}

	public String getHospitalAddress() {
		return hospitalAddress;
	}

	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getSpecialities() {
		return specialities;
	}

	public void setSpecialities(String specialities) {
		this.specialities = specialities;
	}

	public String getEmpanalledDate() {
		return empanalledDate;
	}

	public void setEmpanalledDate(String empanalledDate) {
		this.empanalledDate = empanalledDate;
	}

	public String getMedcoName() {
		return medcoName;
	}

	public void setMedcoName(String medcoName) {
		this.medcoName = medcoName;
	}

	public String getMedcoContactNo() {
		return medcoContactNo;
	}

	public void setMedcoContactNo(String medcoContactNo) {
		this.medcoContactNo = medcoContactNo;
	}

	public String getMitraName() {
		return mitraName;
	}

	public void setMitraName(String mitraName) {
		this.mitraName = mitraName;
	}

	public String getMitraContactNo() {
		return mitraContactNo;
	}

	public void setMitraContactNo(String mitraContactNo) {
		this.mitraContactNo = mitraContactNo;
	}

	public SearchHospitalResult() {
	}

}