package in.kpmg.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StateCountResult {
	@Id
	private String State;
	private String stateid;
	private int Govt;
	private int Pvt;
	
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getGovt() {
		return Govt;
	}
	public void setGovt(int govt) {
		Govt = govt;
	}
	public int getPvt() {
		return Pvt;
	}
	public void setPvt(int pvt) {
		Pvt = pvt;
	}
	public String getStateid() {
		return stateid;
	}
	public void setStateid(String stateid) {
		this.stateid = stateid;
	}
}
