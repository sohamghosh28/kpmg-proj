package in.kpmg.portalsearch.dtos.common;
import javax.persistence.Entity;
import javax.persistence.Id;

	@Entity
public class CountSearchSpecialityResult {
		@Id
	private String proceduresCount;
	public String getProceduresCount() {
		return proceduresCount;
	}
	public void setProceduresCount(String proceduresCount) {
		this.proceduresCount = proceduresCount;
	}
	public String getHospitalsCount() {
		return hospitalsCount;
	}
	public void setHospitalsCount(String hospitalsCount) {
		this.hospitalsCount = hospitalsCount;
	}
	public String getDismainId() {
		return dismainId;
	}
	public void setDismainId(String dismainId) {
		this.dismainId = dismainId;
	}
	private String hospitalsCount;
	private String dismainId;
	private String speciality;
	
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

}
