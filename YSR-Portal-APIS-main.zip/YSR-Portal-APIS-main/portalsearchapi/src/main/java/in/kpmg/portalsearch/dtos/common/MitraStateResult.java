package in.kpmg.portalsearch.dtos.common;
import javax.persistence.Entity;
import javax.persistence.Id;

	@Entity
public class MitraStateResult {

	@Id
	private String locName;
	private String locId;

	public String getLocName() {
		return locName;
	}

	public void setLocName(String locName) {
		this.locName = locName;
	}

	public String getLocId() {
		return locId;
	}

	public void setLocId(String locId) {
		this.locId = locId;
	}

	public int getMitraCount() {
		return mitraCount;
	}

	public void setMitraCount(int mitraCount) {
		this.mitraCount = mitraCount;
	}

	private int mitraCount;


	public MitraStateResult() {
		
	}
}
