package in.kpmg.portalsearch.dtos.common;



public class AdvanceHospitalSearch {
    private String districtid;
    private String hospitalid;
    private String hospitaltype;
	public String getDistrictid() {
		return districtid;
	}
	public void setDistrictid(String districtid) {
		this.districtid = districtid;
	}
	public String getHospitalid() {
		return hospitalid;
	}
	public void setHospitalid(String hospitalid) {
		this.hospitalid = hospitalid;
	}
	public String getHospitaltype() {
		return hospitaltype;
	}
	public void setHospitaltype(String hospitaltype) {
		this.hospitaltype = hospitaltype;
	}
	
	

}