package in.kpmg.portalsearch.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import in.kpmg.portalsearch.dtos.common.AdvanceCountSpecialitySearch;
import in.kpmg.portalsearch.dtos.common.AdvanceDistrictCount;
import in.kpmg.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceMitraDistrict;
import in.kpmg.portalsearch.dtos.common.AdvanceMitraState;
import in.kpmg.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.portalsearch.dtos.common.CountSearchSpecialityResult;
import in.kpmg.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.portalsearch.dtos.common.SearchSpecialityResult;
import in.kpmg.portalsearch.dtos.common.StateCountResult;
import in.kpmg.portalsearch.dtos.common.DisplayResult;
import in.kpmg.portalsearch.dtos.common.DistrictCountResult;
import in.kpmg.portalsearch.dtos.common.MitraDistrictResult;
import in.kpmg.portalsearch.dtos.common.MitraSearchResult;
import in.kpmg.portalsearch.dtos.common.MitraStateResult;

import org.springframework.stereotype.Service;
/*import java.util.ArrayList;*/

@Service
public class PublicService {

	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<SearchHospitalResult> advanceHospitalSearch(AdvanceHospitalSearch request) {

		String nativeQuery ="SELECT ah.hosp_name hospitalName,\n"
				+ "        ah.hosp_type hospitalType,\n"
				+ "                ah.hosp_addr1\n"
				+ "    || ' '\n"
				+ "    || ah.hosp_addr2\n"
				+ "    || ' '\n"
				+ "    || ah.hosp_addr3 hospitalAddress,\n"
				+ "        al.loc_name districtName,\n"
				+ "        spec.specialities_mapped specialities,\n"
				+ "        ah.crt_dt empanalledDate,\n"
				+ "         medco.medco_name medcoName,\n"
				+ "        medco.medco_contact medcoContactNo,\n"
				+ "        mit.mithra_name mitraName,\n"
				+ "        mit.mithra_contact mitraContactNo\n"
				+ "FROM\n"
				+ "    asrim_hospitals ah,\n"
				+ "    asrit_empnl_hospinfo aeh,\n"
				+ "    asrim_locations al,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            LISTAGG(dis_main_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                dis_main_name\n"
				+ "            ) specialities_mapped\n"
				+ "          from  ( select distinct  hosp_id,adm.dis_main_name\n"
				+ "        FROM\n"
				+ "            asrim_hosp_speciality ahs,\n"
				+ "            asrim_phase_duration apd,\n"
				+ "            asrim_disease_main adm\n"
				+ "        WHERE\n"
				+ "            ahs.phase_id = apd.phase_id\n"
				+ "            AND   ahs.renewal = apd.renewal\n"
				+ "-- AND AHS.SPECIALITY_ID='M1'\n"
				+ "            AND   apd.end_dt > SYSDATE\n"
				+ "            AND   ahs.is_active_flg = 'Y'\n"
				+ "            and ahs.speciality_id=adm.dis_main_id)\n"
				+ "        GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) spec,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            LISTAGG(mithra_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                mithra_name\n"
				+ "            ) mithra_name,\n"
				+ "            LISTAGG(cug,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                cug\n"
				+ "            ) mithra_contact\n"
				+ "        from (select distinct hosp_id,au.first_name ||' '|| au.last_name mithra_name,au.cug        \n"
				+ "        FROM\n"
				+ "            asrim_mit_users amu,\n"
				+ "            asrim_users au\n"
				+ "        WHERE\n"
				+ "            amu.user_id = au.user_id\n"
				+ "            AND   amu.eff_end_dt IS NULL)\n"
				+ "        GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) mit,\n"
				+ "        (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            LISTAGG(medco_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                medco_name\n"
				+ "            ) medco_name,\n"
				+ "            LISTAGG(cug,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                cug\n"
				+ "            ) medco_contact\n"
				+ "             from (select distinct hosp_id,au.first_name ||' '|| au.last_name medco_name,au.cug        \n"
				+ "        FROM\n"
				+ "            asrim_nwh_users amu,\n"
				+ "            asrim_users au\n"
				+ "        WHERE\n"
				+ "            amu.user_id = au.user_id\n"
				+ "            AND   amu.eff_end_dt IS NULL)\n"
				+ "        GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) medco\n"
				+ "WHERE\n"
				+ "    ah.hosp_empnl_ref_num = aeh.hospinfo_id\n"
				+ "    AND   ah.hosp_active_yn = 'Y'\n"
				+ "    AND   ah.dist_id = al.loc_id (+)\n"
				+ "    AND   al.loc_hdr_id = 'LH6'\n"
				+ "    AND   spec.hosp_id (+) = ah.hosp_id\n"
				+ "    AND   mit.hosp_id (+) = ah.hosp_id\n"
				+ "    AND   medco.hosp_id (+) = ah.hosp_id\n";
			if(request.getDistrictid() != null)
					nativeQuery = nativeQuery + "   and  ah.dist_id='"+request.getDistrictid()+"'";
			if(request.getHospitalid() != null)
					nativeQuery = nativeQuery +"    and ah.hosp_id='"+request.getHospitalid()+"'";
			if(request.getHospitaltype() != null)
				nativeQuery = nativeQuery + "    and ah.hosp_type ='"+request.getHospitaltype()+"'";
		
		nativeQuery = nativeQuery + " ORDER BY\n"
				+ "loc_name"; //loc_name=District
				

		Query query = em.createNativeQuery(nativeQuery, SearchHospitalResult.class);

		List<SearchHospitalResult> searchResults = query.getResultList();
					
				
		return searchResults;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<SearchSpecialityResult> advanceSpecialitySearch(AdvanceSpecialitySearch request) {

		String nativeQuery = "SELECT hosp_id as hospid, COUNT(nvl(SPECIALITY_ID,0)) count ,\n"
				+ "            LISTAGG(speciality_id,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                speciality_id\n"
				+ "            ) specialitiesmapped \n"
				+ "            FROM(\n"
				+ "SELECT\n"
				+ "            DISTINCT AH.hosp_id, ahs.SPECIALITY_ID\n"
				+ "            FROM\n"
				+ "            ASRIM_PHASE_DURATION apd,\n"
				+ "            ASRIM_SURGERY ASU,\n"
				+ "            ASRIM_HOSP_SPECIALITY ahs\n"
				+ "            RIGHT JOIN ASRIM_HOSPITALS AH ON AH.HOSP_ID=ahs.HOSP_ID\n"
				+ "        WHERE  ahs.phase_id = apd.phase_id\n"
				+ "            AND   ahs.renewal = apd.renewal\n"
				+ "            AND   apd.end_dt > SYSDATE\n"
				+ "            AND   ahs.is_active_flg = 'Y'\n"
				+ "            AND ahs.SPECIALITY_ID=ASU.DIS_MAIN_ID\n"
				+ "            AND ASU.STATE_FLAG IN('AP','N','BOTH') AND ASU.ACTIVE_YN='Y'\n"
				+ "            AND AH.HOSP_ACTIVE_YN='Y') HOSP \n";
		
		if(request.getHospitalid() != null || request.getSpecialityid() != null)
			nativeQuery = nativeQuery +" where ";
		if(request.getHospitalid() != null)
			nativeQuery = nativeQuery +" HOSP_ID='"+request.getHospitalid()+"'";
		
		if (request.getSpecialityid() != null)
			nativeQuery = nativeQuery + "  AND SPECIALITY_ID='"+request.getSpecialityid()+ "'";
		
		nativeQuery = nativeQuery + " GROUP BY hosp_id ";

		Query query = em.createNativeQuery(nativeQuery, SearchSpecialityResult.class);


		List<SearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureResult> advanceProcedureSearch(AdvanceProcedureSearch request) {

		String nativeQuery = "SELECT\n"
				+ "    a.dis_main_id specialityCode,\n"
				+ "    a.dis_main_name specialityName,\n"
				+ "    a.dis_sub_id dissubId,\n"
				+ "    a.dis_name dissubName,\n"
				+ "    a.surgery_id surgeryId,\n"
				+ "    a.surg_disp_code surgdispCode,\n"
				+ "    a.surgery_desc procedureName,\n"
				+ "    a.proc_type procedureType,\n"
				+ "    nvl(hosp_stay_amt,0) + nvl(common_cat_amt,0) + nvl(icd_amt,0) packageAmount,\n"
				+ "    a.hosp_stay_amt hospstayAmt,\n"
				+ "    a.common_cat_amt commoncatAmt,\n"
				+ "    a.icd_amt icdAmt,\n"
				+ "    a.aasara_amout aasaraAmt,\n"
				+ "    a.HOSP_STAY_AMT_GOVT hospstayamtGovt,\n"
				+ "    a.duration_of_stay duration,\n"
				+ "    a.IS_PERDM isPerdm,\n"
				+ "    a.preinvestigations preInvestigations,\n"
				+ "    a.postinvestigations postInvestigations,\n"
				+ "    a.medinvestigations medInvestigations\n"
				+ "FROM\n"
				+ "    (\n"
				+ "         SELECT DISTINCT\n"
				+ "            ad.dis_main_id,\n"
				+ "            ad.dis_main_name,\n"
				+ "            ads.dis_sub_id,\n"
				+ "            ads.dis_name,\n"
				+ "            ac.surgery_id,\n"
				+ "            ac.surg_disp_code,\n"
				+ "            ac.surgery_desc,\n"
				+ "            proc_type,\n"
				+ "            nvl(ahs.hosp_stay_amt,ac.hosp_stay_amt) hosp_stay_amt,\n"
				+ "            nvl(ahs.common_surgery_amt,ac.common_surgery_amt) common_cat_amt,\n"
				+ "            nvl(ahs.buffer_amt,ac.buffer_amt) icd_amt,\n"
				+ "            ac.postops_amt aasara_amout,\n"
				+ "            ac.duration_of_stay,\n"
				+ "            hosp_stay_amt_govt,\n"
				+ "            ac.is_perdm,\n"
				+ "            preinvest.details preinvestigations,\n"
				+ "            postinvest.details postinvestigations,\n"
				+ "            medinvest.details medinvestigations\n"
				+ "        FROM\n"
				+ "            asrim_disease_main ad,\n"
				+ "            asrim_disease_sub ads,\n"
				+ "            asrim_surgery ac,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'PRE'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) preinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'POST'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) postinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'MED'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) medinvest,\n"
				+ "            asrim_hosp_surgeries ahs\n"
				+ "        WHERE\n"
				+ "            ad.dis_main_id = ads.dis_main_id\n"
				+ "            AND   ad.dis_main_id = ac.dis_main_id\n"
				+ "            AND   ads.dis_sub_id = ac.dis_sub_id\n"
				+ "            AND   ac.surgery_id = ahs.surgery_id (+)\n"
				+ "            AND   preinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   postinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   medinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   ac.active_yn = 'Y'\n"
				+ "            AND   ad.dis_active_yn = 'Y'\n"
				+ "            AND   ac.state_flag IN (\n"
				+ "                'BOTH',\n"
				+ "                'AP',\n"
				+ "                'N'\n"
				+ "            )\n";
				//+ "            AND   ac.surgery_id != 'M6.5'\n";
				if(request.getSurgeryid() != null)
					nativeQuery = nativeQuery +" AND   ac.surgery_id != ' "+request.getSurgeryid()+"'\n";

				nativeQuery = nativeQuery
				+ "        UNION\n"
				+ "        SELECT DISTINCT\n"
				+ "            ad.dis_main_id,\n"
				+ "            ad.dis_main_name,\n"
				+ "            ads.dis_sub_id,\n"
				+ "            ads.dis_name,\n"
				+ "            ac.surgery_id,\n"
				+ "            ac.surg_disp_code,\n"
				+ "            ac.surgery_desc,\n"
				+ "            proc_type,\n"
				+ "            nvl(ac.hosp_stay_amt,0) hosp_stay_amt,\n"
				+ "            nvl(ac.common_surgery_amt,0) common_cat_amt,\n"
				+ "            nvl(ac.buffer_amt,0) icd_amt,\n"
				+ "            ac.postops_amt aasara_amout,\n"
				+ "            ac.duration_of_stay,\n"
				+ "            hosp_stay_amt_govt,\n"
				+ "            ac.is_perdm,\n"
				+ "            preinvest.details preinvestigations,\n"
				+ "            postinvest.details postinvestigations,\n"
				+ "            medinvest.details medinvestigations\n"
				+ "        FROM\n"
				+ "            asrim_disease_main ad,\n"
				+ "            asrim_disease_sub ads,\n"
				+ "            asrim_surgery ac,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'PRE'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) preinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'POST'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) postinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'MED'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) medinvest\n"
				+ "        WHERE\n"
				+ "            ad.dis_main_id = ads.dis_main_id\n"
				+ "            AND   ad.dis_main_id = ac.dis_main_id\n"
				+ "            AND   ads.dis_sub_id = ac.dis_sub_id\n"
				+ "            AND   preinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   postinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   medinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   ac.active_yn = 'Y'\n"
				+ "            AND   ad.dis_active_yn = 'Y'\n"
				+ "            AND   ac.state_flag IN (\n"
				+ "                'BOTH',\n"
				+ "                'AP',\n"
				+ "                'N'\n"
				+ "            )\n";
				
				if(request.getSurgeryid() != null)
					nativeQuery = nativeQuery +" AND   ac.surgery_id = '"+request.getSurgeryid()+"'\n";
				//+ "            AND   ac.surgery_id = 'M6.5'\n"
				nativeQuery = nativeQuery
				+ "    ) a\n"
				+ "where a.dis_main_id='S1'\n"
				+ "ORDER BY\n"
				+ "    substr(dis_main_id,0,1) DESC,\n"
				+ "    to_number(substr(dis_main_id,regexp_instr(dis_main_id,'[^A-Z]') ) ),\n"
				+ "    dis_sub_id,\n"
				+ "    surg_disp_code";


		Query query = em.createNativeQuery(nativeQuery, SearchProcedureResult.class);

		List<SearchProcedureResult> searchResults = query.getResultList();		

		return searchResults;

	}
	
	
	@SuppressWarnings("unchecked")
	public List<DisplayResult> display() {

		String nativeQuery = "SELECT aamm.MICR Micr,aamm.CITY City,aamm.BRANCH_NAME branchName,aamm.BANK_NAME bankName FROM ASRIM_ACCT_MICR_MASTER aamm where ROWNUM < 10 ";
		Query query = em.createNativeQuery(nativeQuery, DisplayResult.class);
		List<DisplayResult> searchResults = query.getResultList();
		return searchResults;
	}
	

	@SuppressWarnings("unchecked")
	public List<StateCountResult> advanceStateCount() {

		String nativeQuery = "SELECT\n"
				+ "    state State, stateid, \n"
				+ "    SUM(nvl(govt,0) ) Govt,\n"
				+ "    SUM(nvl(private,0) ) Pvt\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "                CASE\n"
				+ "                    WHEN b.loc_state_val = '6'   THEN 'AndhraPradesh'\n"
				+ "                END\n"
				+ "            AS state, b.loc_state_val as stateid, \n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'G'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS govt,\n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'C'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS private\n"
				+ "        FROM\n"
				+ "            asrim_hospitals a,\n"
				+ "            asrim_locations b\n"
				+ "        WHERE\n"
				+ "            a.dist_id = b.loc_id\n"
				+ "            AND   b.loc_hdr_id = 'LH6'\n"
				+ "            AND   b.loc_state_val = '6'\n"
				+ "            AND   a.isactive_ap = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            loc_state_val,\n"
				+ "            hosp_type\n"
				+ "        UNION\n"
				+ "        SELECT\n"
				+ "                CASE\n"
				+ "                    WHEN b.loc_state_val = '7'   THEN 'Telangana'\n"
				+ "                END\n"
				+ "            AS state, b.loc_state_val as stateid, \n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'G'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS govt,\n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'C'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS private\n"
				+ "        FROM\n"
				+ "            asrim_hospitals a,\n"
				+ "            asrim_locations b\n"
				+ "        WHERE\n"
				+ "            a.dist_id = b.loc_id\n"
				+ "            AND   b.loc_hdr_id = 'LH6'\n"
				+ "            AND   b.loc_state_val = '7'\n"
				+ "            AND   a.isactive_ap = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            loc_state_val,\n"
				+ "            hosp_type\n"
				+ "        UNION\n"
				+ "        SELECT\n"
				+ "                CASE\n"
				+ "                    WHEN b.loc_state_val = '8'   THEN 'Karnataka'\n"
				+ "                END\n"
				+ "            AS state, b.loc_state_val as stateid, \n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'G'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS govt,\n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'C'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS private\n"
				+ "        FROM\n"
				+ "            asrim_hospitals a,\n"
				+ "            asrim_locations b\n"
				+ "        WHERE\n"
				+ "            a.dist_id = b.loc_id\n"
				+ "            AND   b.loc_hdr_id = 'LH6'\n"
				+ "            AND   b.loc_state_val = '8'\n"
				+ "            AND   a.isactive_ap = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            loc_state_val,\n"
				+ "            hosp_type\n"
				+ "        UNION\n"
				+ "        SELECT\n"
				+ "                CASE\n"
				+ "                    WHEN b.loc_state_val = '9'   THEN 'Chennai'\n"
				+ "                END\n"
				+ "            AS state, b.loc_state_val as stateid, \n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'G'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS govt,\n"
				+ "                CASE\n"
				+ "                    WHEN hosp_type = 'C'   THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS private\n"
				+ "        FROM\n"
				+ "            asrim_hospitals a,\n"
				+ "            asrim_locations b\n"
				+ "        WHERE\n"
				+ "            a.dist_id = b.loc_id\n"
				+ "            AND   b.loc_hdr_id = 'LH6'\n"
				+ "            AND   b.loc_state_val = '9'\n"
				+ "            AND   a.isactive_ap = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            loc_state_val,\n"
				+ "            hosp_type\n"
				+ "    )\n"
				+ "GROUP BY\n"
				+ "    state, stateid";
		Query query = em.createNativeQuery(nativeQuery, StateCountResult.class);
		List<StateCountResult> searchResults = query.getResultList();
		return searchResults;
	}
	
	@SuppressWarnings("unchecked")
	public List<DistrictCountResult> advanceDistrictCount(AdvanceDistrictCount request) {

		String nativeQuery ="SELECT\n"
				+ "    district District,\n"
				+ "    SUM(nvl(govt ,0) ) Govt,\n"
				+ "    SUM(nvl(private ,0) ) Private\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            b.loc_name district,\n"
				+ "            CASE\n"
				+ "                    WHEN hosp_type = 'G' THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS govt,\n"
				+ "            CASE\n"
				+ "                    WHEN hosp_type = 'C' THEN COUNT(a.hosp_id)\n"
				+ "                END\n"
				+ "            AS private\n"
				+ "        FROM\n"
				+ "            asrim_hospitals a,\n"
				+ "            asrim_locations b\n"
				+ "        WHERE\n"
				+ "            a.dist_id = b.loc_id\n"
				+ "            AND   b.loc_hdr_id = 'LH6'\n";
				
			if(request.getStateVal() != null)
					nativeQuery = nativeQuery + "  AND   b.loc_state_val='"+request.getStateVal()+"'";
			
		nativeQuery = nativeQuery + " AND   a.isactive_ap = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            b.loc_name,\n"
				+ "            hosp_type\n"
				+ "    )\n";
		
		nativeQuery = nativeQuery + "GROUP BY\n"
				+ "    district";	

		Query query = em.createNativeQuery(nativeQuery, DistrictCountResult.class);

		List<DistrictCountResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	
	@SuppressWarnings("unchecked")
	public List<MitraSearchResult> advanceMitraSearch() {

		String nativeQuery = "SELECT\n"
				+ "d.loc_state_val locstateVal, \n"
				+ "    case when d.loc_state_val= '7' then 'TELAGANA'\n"
				+ "    when d.loc_state_val= '9' then 'TAMILNADU'\n"
				+ "    when d.loc_state_val= '8' then 'KARNATAKA'\n"
				+ "    when d.loc_state_val= '6' then 'ANDHRA PRADESH'\n"
				+ "    else 'OTHERS' end AS state,\n"
				+ "    COUNT(a.user_id) mitraCount\n"
				+ "FROM\n"
				+ "    asrim_users a,\n"
				+ "    asrim_mit_users b,\n"
				+ "    asrim_hospitals c,\n"
				+ "    ( SELECT * FROM asrim_locations\n"
				+ "        WHERE\n"
				+ "            loc_hdr_id = 'LH6'\n"
				+ "            AND   active_yn = 'Y') d\n"
				+ "WHERE\n"
				+ "    a.user_id = b.user_id\n"
				+ "    AND   b.hosp_id = c.hosp_id\n"
				+ "    AND   c.dist_id = d.loc_id\n"
				+ "    AND   a.user_role = 'CD10'\n"
				+ "    AND   a.active_yn = 'Y'\n"
				+ "    AND   b.eff_end_dt IS NULL\n"
				+ "GROUP BY\n"
				+ "    d.loc_state_val";
		Query query = em.createNativeQuery(nativeQuery, MitraSearchResult.class);
		List<MitraSearchResult> searchResults = query.getResultList();
		return searchResults;
	}
	
	@SuppressWarnings("unchecked")
	public List<MitraStateResult> advanceMitraStateCount(AdvanceMitraState request) {

		String nativeQuery ="SELECT\n"
				+ "        a.loc_name locName,\n"
				+ "        a.loc_id locId,\n"
				+ "        SUM(mitra_count) mitraCount\n"
				+ "FROM\n"
				+ "    (SELECT\n"
				+ "            d.loc_name,d.loc_id,d.loc_state_val,\n"
				+ "            COUNT(a.user_id) mitra_count\n"
				+ "        FROM\n"
				+ "            asrim_users a,\n"
				+ "            asrim_mit_users b,\n"
				+ "            asrim_hospitals c,\n"
				+ "            (SELECT * FROM asrim_locations\n"
				+ "                WHERE loc_hdr_id = 'LH6' AND   active_yn = 'Y') d\n"
				+ "        WHERE\n"
				+ "            a.user_id = b.user_id\n"
				+ "            AND   b.hosp_id = c.hosp_id\n"
				+ "            AND   c.dist_id = d.loc_id\n"
				+ "            AND   a.user_role = 'CD10'\n"
				+ "            AND   a.active_yn = 'Y'\n"
				+ "            AND   b.eff_end_dt IS NULL\n"
				+ "        GROUP BY\n"
				+ "            d.loc_name,d.loc_id,d.loc_state_val) a\n"
				+ "WHERE\n";
				
			if(request.getStateid() != null)
					nativeQuery = nativeQuery + " a.loc_state_val='"+request.getStateid()+"'\n";
			
		
		nativeQuery = nativeQuery + "GROUP BY\n"
				+ "    a.loc_name,a.loc_id";	

		Query query = em.createNativeQuery(nativeQuery, MitraStateResult.class);

		List<MitraStateResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictResult> advanceMitraDistrictCount(AdvanceMitraDistrict request) {

		String nativeQuery ="SELECT\n"
				+ "    a.name_of_mitra mitraName,\n"
				+ "    a.mitra_contact_number mitraContact,\n"
				+ "    a.district district,\n"
				+ "    a.district_id districtid,\n"
				+ "    a.name_of_hospital hospitalName,\n"
				+ "    b.specialities Speciality\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            LISTAGG(a.first_name\n"
				+ "            || ' '\n"
				+ "            || a.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                a.first_name\n"
				+ "                || ' '\n"
				+ "                || a.last_name\n"
				+ "            ) AS name_of_mitra,\n"
				+ "            LISTAGG(a.cug,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                a.cug\n"
				+ "            ) AS mitra_contact_number,\n"
				+ "            d.loc_id AS district_id,\n"
				+ "            d.loc_name AS district,\n"
				+ "            c.hosp_id,\n"
				+ "            c.hosp_name AS name_of_hospital\n"
				+ "        FROM\n"
				+ "            asrim_users a,\n"
				+ "            asrim_mit_users b,\n"
				+ "            asrim_hospitals c,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    *\n"
				+ "                FROM\n"
				+ "                    asrim_locations\n"
				+ "                WHERE\n"
				+ "                    loc_hdr_id = 'LH6'\n"
				+ "                    AND   loc_state_val = '6'\n"
				+ "                    AND   active_yn = 'Y'\n"
				+ "            ) d\n"
				+ "        WHERE\n"
				+ "            a.user_id = b.user_id\n"
				+ "            AND   b.hosp_id = c.hosp_id\n"
				+ "            AND   c.dist_id = d.loc_id\n"
				+ "            AND   a.user_role = 'CD10'\n"
				+ "            AND   a.active_yn = 'Y'\n"
				+ "            AND   b.eff_end_dt IS NULL\n"
				+ "        GROUP BY\n"
				+ "            d.loc_id,\n"
				+ "            d.loc_name,\n"
				+ "            c.hosp_id,\n"
				+ "            c.hosp_name\n"
				+ "        ORDER BY\n"
				+ "            d.loc_name\n"
				+ "    ) a,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            c.hosp_id,\n"
				+ "            LISTAGG(adm.dis_main_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                  adm.dis_main_name) specialities\n"
				+ "        FROM\n"
				+ "            asrim_hospitals c,\n"
				+ "            asrim_hosp_speciality ahs,\n"
				+ "            asrim_disease_main adm\n"
				+ "        WHERE\n"
				+ "            c.hosp_id = ahs.hosp_id\n"
				+ "            AND   ahs.phase_id = '6'\n"
				+ "            AND   ahs.renewal = '8'\n"
				+ "            AND   ahs.is_active_flg = 'Y'\n"
				+ "            AND   c.isactive_ap = 'Y'\n"
				+ "            and  ahs.speciality_id=adm.dis_main_id\n"
				+ "        GROUP BY\n"
				+ "            c.hosp_id\n"
				+ "    ) b\n"
				+ "WHERE\n"
				+ "    a.hosp_id = b.hosp_id\n";
				
			if(request.getDistrictid() != null)
					nativeQuery = nativeQuery + " and a.district_id='"+request.getDistrictid()+"'";
			

		Query query = em.createNativeQuery(nativeQuery, MitraDistrictResult.class);

		List<MitraDistrictResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	
	@SuppressWarnings("unchecked")
	public List<CountSearchSpecialityResult> advanceCountSpecialitySearch(AdvanceCountSpecialitySearch request) {

		String nativeQuery = "SELECT DISTINCT\n"
				+ "    a.dis_main_id dismainId,\n"
				+ "    upper(b.dis_main_name\n"
				+ "    || ' ( '\n"
				+ "    || a.dis_main_id\n"
				+ "    || ' )') speciality,\n"
				+ "    SUM(a.surgery_id) proceduresCount,\n"
				+ "    SUM(b.hosp_id) hospitalsCount\n"
				+ "    \n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            asu.dis_main_id,\n"
				+ "            COUNT(asu.surgery_id) surgery_id\n"
				+ "        FROM\n"
				+ "            asrim_surgery asu\n"
				+ "        WHERE\n"
				+ "            asu.state_flag IN (\n"
				+ "                'AP',\n"
				+ "                'N',\n"
				+ "                'BOTH'\n"
				+ "            )\n"
				+ "            AND   asu.active_yn = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            asu.dis_main_id\n"
				+ "    ) a,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            adm.dis_main_id,\n"
				+ "            adm.dis_main_name,\n"
				+ "            COUNT(ahs.hosp_id) hosp_id\n"
				+ "        FROM\n"
				+ "            asrim_disease_main adm,\n"
				+ "            asrim_hosp_speciality ahs\n"
				+ "        WHERE\n"
				+ "            adm.dis_main_id =ahs.speciality_id\n";
		
		nativeQuery = nativeQuery + "AND   adm.dis_active_yn = 'Y'\n"
				+ "            AND   phase_id = '6'\n"
				+ "            AND   renewal = '8'\n"
				+ "            AND   is_active_flg = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            adm.dis_main_id,\n"
				+ "            adm.dis_main_name\n"
				+ "    ) b\n"
				+ "WHERE\n"
				+ "    a.dis_main_id = b.dis_main_id\n"
				+ "GROUP BY\n"
				+ "    b.dis_main_name,\n"
				+ "    a.dis_main_id order by Speciality";

		Query query = em.createNativeQuery(nativeQuery, CountSearchSpecialityResult.class);


		List<CountSearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
}