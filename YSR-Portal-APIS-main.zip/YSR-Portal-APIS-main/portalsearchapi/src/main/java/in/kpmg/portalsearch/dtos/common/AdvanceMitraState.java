package in.kpmg.portalsearch.dtos.common;

public class AdvanceMitraState {
	private String stateid;

	public String getStateid() {
		return stateid;
	}

	public void setStateid(String stateid) {
		this.stateid = stateid;
	}
}
