package in.kpmg.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DistrictCountResult {

	@Id
	private String District;
	private int Govt;
	private int Private;
	public String getDistrict() {
		return District;
	}
	public void setDistrict(String district) {
		District = district;
	}
	public int getGovt() {
		return Govt;
	}
	public void setGovt(int govt) {
		Govt = govt;
	}
	public int getPrivate() {
		return Private;
	}
	public void setPrivate(int private1) {
		Private = private1;
	}
}