package in.soham;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SohamStateApplicationTests {

	@Test
	void contextLoads() {
	}

}
