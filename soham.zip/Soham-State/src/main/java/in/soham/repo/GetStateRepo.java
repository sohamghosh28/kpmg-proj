package in.soham.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import in.soham.model.GetStateModel;

public interface GetStateRepo extends CrudRepository<GetStateModel, Long> {
	
	@Query(value="SELECT DISTINCT DECODE(LOC_STATE_VAL, '6', 'ANDHRA PRADESH','7', 'TELANGANA','8', 'KARNATAKA', '9', 'TAMIL NADU',NULL) STATE_NAME FROM ASRIM_LOCATIONS WHERE LOC_STATE_VAL IS NOT NULL",nativeQuery = true)
	List<GetStateModel> getState();

}
