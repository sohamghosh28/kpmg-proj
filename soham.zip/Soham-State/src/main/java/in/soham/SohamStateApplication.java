package in.soham;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import in.soham.service.GetStateService;

@SpringBootApplication
@RestController
public class SohamStateApplication {
	
	@Autowired
	GetStateService getStateService;

	public static void main(String[] args) {
		SpringApplication.run(SohamStateApplication.class, args);
		
		
	}
	
	@GetMapping("/get")
	public String getState() {
		return getStateService.getState();
	}

}
