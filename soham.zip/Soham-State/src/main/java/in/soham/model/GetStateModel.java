package in.soham.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class GetStateModel {
	
	
	@Id
	public String State_Name;

}
