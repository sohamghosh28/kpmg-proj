package in.soham.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.soham.model.GetStateModel;
import in.soham.repo.GetStateRepo;

@Service
public class GetStateService {
	
	@Autowired
	GetStateRepo getStateRepo;
	
	public String getState() {
		
		List<GetStateModel> list=getStateRepo.getState();
		if(list.isEmpty())
		return "No Result Found"; 
		return "Result Found";
		
	}

}
